require("./database/module");
global.storename = "𝐋𝐮𝐱𝐳𝐲𝐒𝐭𝐨𝐫𝐞";
global.dana = "6285180864119";
global.qris = "https://files.catbox.moe/t0tfgc.jpg";
global.owner = "6285180864119";
global.namabot = ""; // BIARIN AE BRE KOSONG
global.nomorbot = "6285180864119";
global.nameCreator = ""; // BIARIN AE BRE KOSONG
global.linkyt = "https://youtube.com/@LuxzyTeach";
global.autoJoin = false;
global.antilink = true;
global.versisc = "2.9.0";
global.delayjpm = 5500;
global.codeInvite = ""; // BIARIN AE BRE KOSONG
global.imageurl = "https://files.catbox.moe/t0tfgc.jpg";
global.isLink = "https://whatsapp.com/channel/0029Vat6H2mDzgTLUCksdw2u";
global.packname = ""; // BIARIN AE BRE KOSONG
global.author = ""; // BIARIN AE BRE KOSONG
global.jumlah = "5";
let v = require.resolve(__filename);
fs.watchFile(v, () => {
  fs.unwatchFile(v);
  console.log(chalk.redBright("Update " + __filename));
  delete require.cache[v];
  require(v);
});